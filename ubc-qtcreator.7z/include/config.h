#define BUILD_TYPE "Debug"
#define OGRE_PLUGIN_DIR "C:/Users/libolt/builds/ogre-1.10-build/sdk/bin/debug"
#define UBC_DATADIR "C:/Users/libolt/Projects/ubc-qtcreator/data"
