#define BUILD_TYPE "Release"
#define OGRE_PLUGIN_DIR "${OGRE_PLUGIN_DIR}"
#define UBC_DATADIR "."
